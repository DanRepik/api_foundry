from utils.logger import logger
from .service import ServiceAdapter
from connectors.connector_factory import connector_factory

log = logger(__name__)

class TransactionalService(ServiceAdapter):

  def execute(self, *, store_params: dict, query_params: dict, metadata_params: dict):
      pass

  def mutate(connector: Connector, operation, **args) -> list:
    """
    Execute a mutation operation on the database.
    """
    connection = connector_factory(engine=, schema=)
    try:
        result = operation(connection=connection, **args)
        connection.commit()
        publish_notification(**args)

    except AppException as error:
        log.error(f"transaction exception: {error}")
        log.error(f"traceback: {traceback.format_exc()}")
        raise error

    finally:
        connection.close()

    return result

