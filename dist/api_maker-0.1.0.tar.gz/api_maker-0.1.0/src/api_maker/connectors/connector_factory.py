from .connector import Connector
from utils.logger import logger

db_config_map = dict()


def connector_factory(engine: str, schema: str) -> Connector:
    """
    Factory function to create a database connector based on the specified engine and schema.

    Args:
    - engine (str): The database engine type ('postgres', 'oracle', or 'mysql').
    - schema (str): The schema for the database.

    Returns:
    - Connector: An instance of the appropriate Connector subclass.
    """
    # Get the secret name based on the engine and schema from the secrets map
    secret_name = __get_db_config(f"{engine}|{schema}")

    # Determine the database engine type and return the corresponding Connector instance
    if engine == "postgres":
        from .postgres_connector import PostgresConnector
        return PostgresConnector(db_secret_name=secret_name, schema=schema)
    elif engine == "oracle":
        from .oracle_connector import OracleConnector
        return OracleConnector(db_secret_name=secret_name)
    elif engine == "mysql":
        from .mysql_connector import MySqlConnector
        return MySqlConnector(db_secret_name=secret_name)

    # Raise a ValueError for an invalid database type
    raise ValueError("Invalid database type. Must be 'postgres', 'oracle', or 'mysql'.")

def __get_db_config(self, db_secret_name: str):
    """
    Set the database configuration based on the secret name.

    Parameters:
    - db_secret_name (str): The name of the AWS Secrets Manager secret.

    Returns:
    - None
    """
    # Try to load secret from global cache
    global db_config_map
    db_config = db_config_map.get(db_secret_name, None)

    # If the cache is not found, get the secret from AWS Secrets Manager
    # and add it to the cache object.
    if not db_config:
        log.info(f"db_config not cached {db_secret_name}")
        db_config = self.get_secret(db_secret_name)
        db_config_map[db_secret_name] = db_config

    return db_config            

