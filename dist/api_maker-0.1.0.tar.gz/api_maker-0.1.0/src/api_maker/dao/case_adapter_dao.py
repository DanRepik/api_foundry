from humps import camelize, decamelize

from .dao import DAOAdapter


class CaseAdapterDAO(DAOAdapter):

    def execute(
        self,
        *,
        entity: str,
        operation: str,
        store_params: dict,
        query_params: dict,
        metadata_params: dict,
    ):

        # determine case
        camel_case = (
            query_params.get("_case", "snake") == "camel"
            or self.__check_camel_case(store_params)
            or self.__check_camel_case(query_params)
        )

        result = super().execute(
            entity=entity,
            operation=operation,
            store_params=decamelize(store_params) if camel_case else store_params,
            query_params=decamelize(query_params) if camel_case else query_params,
            metadata_params=metadata_params,
        )

        if not camel_case:
            return result
        
        converted_result = []
        for item in result:
            converted_result.append(camelize(item))

        # convert back to camel case if needed
        return converted_result

    # check column map for any keys that contain an upper case character

    def __check_camel_case(self, params: dict) -> bool:
        if params is not None:
            # check the keys for an upper case character
            for param in params:
                if (
                    param != param.lower()
                    and param != param.upper()
                    and "_" not in param
                ):
                    return True

        return False
