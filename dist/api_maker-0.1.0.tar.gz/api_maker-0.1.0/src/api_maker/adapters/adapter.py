import abc
import json

from utils.logger import logger
from services.service import Service

log = logger(__name__)

class Adapter(metaclass=abc.ABCMeta):

    @classmethod
    def __subclasshook__(cls, __subclass: type) -> bool:
        return (hasattr(__subclass, 'marshal')
                and callable(__subclass.marshal)
                and hasattr(__subclass, 'umarshal')
                and callable(__subclass.unmarshal))

    def __init__(self, service: Service) -> None:
        self.service = service
        
    def unmarshal(self, event):
        """
        Unmarshal the event in a tuple for processing

        Parameters:
        - event (dict): Lambda event object.

        Returns:
        - tuple: Tuple containing entity operation, store_params, query_params and metadata params.
        """
        raise NotImplementedError

    def marshal(self, result: list[dict]):
        """
        Marshal the result into a event response

        Parameters:
        - result (list): the data set to return in the response

        Returns:
        - the event response
        """
        raise NotImplementedError

    def process_event(self, service: Service, event):
        """
        Process Lambda event using a domain function.

        Parameters:
        - service_function (callable): The service function to be executed.
        - event (dict): Lambda event object.

        Returns:
        - any: Result of the domain function.
        """
        (entity, operation, store_params, query_params, metadata_params) = self.unmarshal(event)

        result = self.service.execute(
            entity=entity,
            operation=operation,
            query_params=query_params,
            store_params=store_params,
            metadata_params=metadata_params
        )
        log.debug(f"adapter result: {result}")

        return self.marshal(result)
