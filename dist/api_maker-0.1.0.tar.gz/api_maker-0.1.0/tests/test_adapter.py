from api_maker.services.service import Service
from api_maker.adapters.adapter import Adapter

class MockService(Service):
    def execute(self, entity, operation, query_params, store_params, metadata_params):
        # Simulating service execution and returning dummy result
        assert entity == "entity"
        assert operation == "operation"
        assert query_params == {"query", "query"}
        return [{"key": "value"}]
    
# Mock adapter provides provides abstract functions for Adapter class
class MockAdapter(Adapter):
    def marshal(self, result: list[dict]):
        return result
    
    def unmarshal(self, event):
        return "entity", "operation", { "store", "store"}, {"query", "query"}, {"metadata", "metadata"}

class TestAdapter():

    def test_stub(self):
        return True

    def xtest_adapter(self):
        mock_service = MockService()
        mock_adapter = MockAdapter(service=mock_service)

        # Calling the process_event method
        result = mock_adapter.process_event(service=mock_service, event={})

        # Asserting the result
        assert result == [{"key": "value"}]
